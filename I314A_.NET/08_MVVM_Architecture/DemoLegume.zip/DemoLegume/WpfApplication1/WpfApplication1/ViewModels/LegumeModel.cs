﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication1.Models;

namespace WpfApplication1.ViewModels
{
    class LegumeModel
    {
        private readonly Legume _legume;
 
        
        public LegumeModel(Legume legume)
        {
            _legume = legume;
        }
        
        
        public int Id {
            get { return _legume.id; }
        }

        public string Name
        {
            get { return _legume.name; }
        }
    }
}
