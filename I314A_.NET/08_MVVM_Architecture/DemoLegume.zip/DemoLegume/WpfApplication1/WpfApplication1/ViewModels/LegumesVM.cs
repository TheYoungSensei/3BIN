﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApplication1.Models;

namespace WpfApplication1.ViewModels
{
    class LegumesVM
    {
        private List<LegumeModel> _legumesList;
        private PotagerEntities1 context = new PotagerEntities1();


        public List<LegumeModel> LegumesList {
            get {
                //if (_legumesList == null) _legumesList = loadLegumes2();
                //return _legumesList;
                return _legumesList = _legumesList ?? loadLegumes2();
            }
        }


       /* private List<LegumeModel> loadLegumes2()
        {
            List<Legume> localCollection = new List<Legume>();
            foreach (var item in context.Legumes)
            {
                localCollection.Add(item);

            }

            return localCollection;

        } */
         

        private List<LegumeModel> loadLegumes2()
        {
            List<LegumeModel> localCollection = new List<LegumeModel>();
            foreach (var item in context.Legumes)
            {
                localCollection.Add(new LegumeModel(item));

            }

            return localCollection;

        }


      
    }
}
