﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExtensionMethods
{
    class Program
    {
        static void Main(string[] args)
        {

            String test = "abcdefgh";

            Console.WriteLine("inverse: " + test.inversion());

            Console.ReadLine();

        }
    }
}
