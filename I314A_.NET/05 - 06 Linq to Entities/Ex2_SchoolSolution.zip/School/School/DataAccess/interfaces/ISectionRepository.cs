﻿using School.DataAccess;
using ModèleObjet.Model;

namespace School.Model.Repository
{
    public interface ISectionRepository : IRepository<Section>
    {

      
    
    }
}
