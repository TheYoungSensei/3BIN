﻿namespace School.Model.Repository
{
    public interface IProfessorRepository
    {
      

    
    }
}
