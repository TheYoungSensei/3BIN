﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfServiceStudent
{
    public class Student
    {
        private string name {get;set};
        private string firstname;
    }
}