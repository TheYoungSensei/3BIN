﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceStudent
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IService1" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IStudent
    {

        [OperationContract]
        List<Student> lister();

        [OperationContract]
        bool addStud(string name, string firstname, DateTime datenaiss);

       // [OperationContract]
       // bool deleteStud(string name, string firstname, DateTime datenaiss);

    }



}
