﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Collections;

namespace WcfServiceStudent
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "Service1" dans le code, le fichier svc et le fichier de configuration.
    //[ServiceBehavior(InstanceContextMode=InstanceContextMode.PerSession)]
    public class StudentImpl : IStudent
    {
        protected static List<Student> liste = new List<Student>();
        // attention ceci est appellé lors du déploiement du service par IIS
        public StudentImpl()
        {
          
        }

        public List<Student> lister()
        {
            return liste;
        }


        public bool addStud(string name, string firstname, DateTime datenaiss)
        {
            Student s = new Student();
            s.firstname = firstname;
            s.name = name;
            s.datenaiss = datenaiss;
            s.paysnaiss = "BE";
            liste.Add(s);
            if (liste.Contains(s)) return true;
            else return false;
        }


    }
}
