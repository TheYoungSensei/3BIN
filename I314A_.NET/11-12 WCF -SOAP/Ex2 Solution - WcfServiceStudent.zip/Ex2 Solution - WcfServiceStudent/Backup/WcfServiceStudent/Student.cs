﻿using System;
using System.Runtime.Serialization;

[DataContract]
public class Student
{
    [DataMember]
    public string name {get; set;}

    [DataMember]
    public string firstname { get; set; }

    [DataMember]
    public DateTime datenaiss {get;set;}

    public string paysnaiss { get; set; }

}
