﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ConsoleApplication1.ServiceReference1;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            ServiceReference1.StudentClient proxy = new ServiceReference1.StudentClient();

            bool ok = proxy.addStud("tata","tata",new DateTime());

            Console.WriteLine("ok ? : " + ok);

            List<Student> liste = proxy.lister();

            foreach (Student stud in liste)
            {
                Console.WriteLine(stud.firstname + stud.name + stud.datenaiss);
            }


            Console.ReadLine();

            

          


        }
    }
}
