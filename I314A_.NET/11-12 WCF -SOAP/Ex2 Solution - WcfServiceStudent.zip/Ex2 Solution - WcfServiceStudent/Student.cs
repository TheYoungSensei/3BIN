﻿using System;

public class Student
{

    private string name {get; set;}

    private string firstname { get; set; }

	public Student(string name, string firstname)
	{
        this.name = name;
        this.firstname = firstname;
	}
}
