﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfServiceClient.Models;

namespace WcfServiceClient
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "WcfServiceClientImpl" dans le code, le fichier svc et le fichier de configuration.
    // REMARQUE : pour lancer le client test WCF afin de tester ce service, sélectionnez WcfServiceClientImpl.svc ou WcfServiceClientImpl.svc.cs dans l'Explorateur de solutions et démarrez le débogage.

    // Singleton
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
    public class WcfServiceClientImpl : IServiceCustomer
    {
        private readonly NorthwindEntities _nwEntities = new NorthwindEntities();

        // constantes PBKDF2
        private const int SaltByteSize = 24;
        private const int HashByteSize = 20; // to match the size of the PBKDF2-HMAC-SHA-1 hash 
        private const int Pbkdf2Iterations = 1000;
        private const int IterationIndex = 0;
        private const int SaltIndex = 1;
        private const int Pbkdf2Index = 2;

        public bool AddCustomer(string customerId, string companyName, string contactName, string password)
        {
            Customer cust = (from Customer c in _nwEntities.Customers
                where c.CustomerID.Equals(customerId)
                select c).FirstOrDefault();

            // client existe déjà
            if (cust != null) return false;
            // sinon
            _nwEntities.Customers.Add(new Customer()
            {
                CustomerID = customerId,
                CompanyName = companyName,
                ContactName = contactName
            });
            _nwEntities.Users.Add(new User() {CustomerID = customerId, password = HashPassword(password)});
            _nwEntities.SaveChanges();
            return true;
        }

        private static string HashPassword(string password)
        {
            var cryptoProvider = new RNGCryptoServiceProvider();
            byte[] salt = new byte[SaltByteSize];
            cryptoProvider.GetBytes(salt);

            var hash = GetPbkdf2Bytes(password, salt, Pbkdf2Iterations, HashByteSize);
            return Pbkdf2Iterations + ":" +
                   Convert.ToBase64String(salt) + ":" +
                   Convert.ToBase64String(hash);
        }

        private static byte[] GetPbkdf2Bytes(string password, byte[] salt, int iterations, int outputBytes)
        {
            var pbkdf2 = new Rfc2898DeriveBytes(password, salt);
            pbkdf2.IterationCount = iterations;
            return pbkdf2.GetBytes(outputBytes);
        }
    }
}