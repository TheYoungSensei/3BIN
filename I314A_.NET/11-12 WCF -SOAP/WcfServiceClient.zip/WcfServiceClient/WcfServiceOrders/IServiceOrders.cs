﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfServiceOrders.Models;

namespace WcfServiceOrders
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IServiceOrders" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IServiceOrders
    {
        [OperationContract]
        List<ProductDTO> GetAllProducts();

        [OperationContract]
        string AddToCart(string customerId, string productName, short quantity);

        [OperationContract]
        Dictionary<ProductDTO, int> ViewCart();

        [OperationContract]
        bool OrderCart();


    }

    [DataContract]
    public class ProductDTO
    {
        [DataMember]
        public string ProductName {get; set; }
    }
}
