﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfServiceOrders.Models;

namespace WcfServiceOrders
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "ServiceOrders" dans le code, le fichier svc et le fichier de configuration.
    // REMARQUE : pour lancer le client test WCF afin de tester ce service, sélectionnez ServiceOrders.svc ou ServiceOrders.svc.cs dans l'Explorateur de solutions et démarrez le débogage.
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession)]
    public class ServiceOrders : IServiceOrders
    {
        private readonly NorthwindEntities _nwEntities = new NorthwindEntities();
    
        private Dictionary<Product, short> _cart;
        private Customer _cust = null;

        public ServiceOrders()
        {
            _cart = new Dictionary<Product, short>();
        }

        public List<ProductDTO> GetAllProducts()
        {
            List<Product> lst = _nwEntities.Products.ToList();
            List<ProductDTO> lstProducts = new List<ProductDTO>();
            foreach (Product p in lst)
            {
                lstProducts.Add(new ProductDTO() {ProductName = p.ProductName});
            }
            return lstProducts;
        }

        public string  AddToCart(string customerId, string productName, short quantity)
        {
            if (_cust == null)
            {
                Customer c = (from Customer cust in _nwEntities.Customers
                    where cust.CustomerID.Equals(customerId)
                    select cust).FirstOrDefault();
                if (c == null) throw new FaultException("Client inconnu"+ customerId);
                _cust = c;
            }

            Product p = (from Product prod in _nwEntities.Products
                where prod.ProductName.Equals(productName)
                select prod).FirstOrDefault();
            if (p == null) throw new FaultException("Produit inconnu "+productName);

            if (_cart.ContainsKey(p))
            {
                _cart[p] += quantity;
            }
            else
            {
                _cart.Add(p, quantity);
            }
            return OperationContext.Current.SessionId;
        }

        public Dictionary<ProductDTO, int> ViewCart()
        {
            Dictionary<ProductDTO,int> cartTDO = new Dictionary<ProductDTO,int>();
            foreach (var prod in _cart)
            {
                ProductDTO po = new ProductDTO();
                po.ProductName = prod.Key.ProductName;
                cartTDO.Add(po, prod.Value);
            }
            return cartTDO;
        }

        public bool OrderCart()
        {

            Order o = new Order {CustomerID = _cust.CustomerID};
     
            _nwEntities.Orders.Add(o);
            foreach (var product in _cart)
            {
                _nwEntities.Order_Details.Add(new Order_Detail
                {
                    ProductID = product.Key.ProductID,
                    Quantity = product.Value,
                    Order = o
                    
                });
            }
            _nwEntities.SaveChanges();
            return true;
        }
    }
}
