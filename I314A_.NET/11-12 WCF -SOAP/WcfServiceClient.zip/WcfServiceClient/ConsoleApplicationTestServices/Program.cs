﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using ConsoleApplicationTestServices.ServiceReferenceOrders;


namespace ConsoleApplicationTestServices
{
    class Program
    {
        static void Main(string[] args)
        {
   
            ServiceReferenceOrders.ServiceOrdersClient svcOrders = new ServiceOrdersClient();
           /* svcOrders.ClientCredentials.Windows.ClientCredential.UserName = "xxxxx";
            svcOrders.ClientCredentials.Windows.ClientCredential.Password = "xxxxxx";
            svcOrders.ClientCredentials.Windows.ClientCredential.Domain = "xxxxx";*/
            List<ProductDTO> lst = svcOrders.GetAllProducts();

            foreach (ProductDTO p in lst )
            {
                Console.WriteLine(p.ProductName);
            }

            Console.ReadLine();

            try
            {
                Console.WriteLine(svcOrders.AddToCart("ALFKI", "Chai", 5));
                Console.WriteLine(svcOrders.AddToCart("ALFKI", "Chai", 7));
            }
            catch (FaultException e)
            {
                Console.WriteLine(e);
            }

            Console.WriteLine(svcOrders.InnerChannel.SessionId);

            Dictionary<ProductDTO, int> cart = svcOrders.ViewCart();

            foreach (var d in cart)
            {
                Console.WriteLine("{0} -> {1}",d.Key, d.Value);
            }

            svcOrders.OrderCart();

            Console.ReadLine();

        }
    }
}
