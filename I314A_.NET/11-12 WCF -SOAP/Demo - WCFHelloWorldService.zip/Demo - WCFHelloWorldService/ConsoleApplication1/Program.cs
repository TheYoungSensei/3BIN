﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClientApplication
{
    class Program
    {
        static void Main(string[] args)
        {

            ServiceReference1.HelloWorldClient client = new ServiceReference1.HelloWorldClient();

            Console.WriteLine(client.sayHello());
            Console.ReadLine();
        }
    }
}
