﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClientWCFServiceBancaire
{
    class Program
    {
        static void Main(string[] args)
        {
            // utilisation de la classe proxy créée par WCF
            ServiceReference1.BanqueClient proxy = new ServiceReference1.BanqueClient();
            double valeur = proxy.calculTVA(100.0,"BE");
            Console.WriteLine(valeur);
            Console.ReadLine();
        }
    }
}
