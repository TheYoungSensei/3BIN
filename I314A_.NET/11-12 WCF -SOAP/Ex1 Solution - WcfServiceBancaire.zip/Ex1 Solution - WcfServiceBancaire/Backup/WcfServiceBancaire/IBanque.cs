﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceBancaire
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IService1" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IBanque
    {
        // renvoie la valeur augmentée de la TVA suivant le pays
        // Ex : calculTVA(100,"BE") renvoie 121
        // FR -> 19.06 %
        // BE -> 21 %
        // DE -> 19 %
        [OperationContract]
        double calculTVA(double valeur, string pays);

        // renvoie la valeur multipliée par un nombre aléatoire compris entre 0 et 1.
        // nombre aléatoire -> aller voir la classe Random
        [OperationContract]
        double criseBancaire(double valeur);

        
    }


   
}
