﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfServiceBancaire
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "Service1" dans le code, le fichier svc et le fichier de configuration.
    public class BanqueImpl : IBanque
    {

        public double calculTVA(double valeur, string pays)
        {
           double coeff;
           switch (pays)
           {
               case "BE": coeff = 1.21;
                          break;
               case "FR": coeff = 1.1906;
                          break;
               case "DE": coeff = 1.19;
                          break;
               default: coeff = 1.21;
                          break; 
           }

           return valeur * coeff;
        }

        public double criseBancaire(double valeur)
        {
            Random generateur = new Random();
            return valeur * generateur.NextDouble();
        }

        
    }
}
