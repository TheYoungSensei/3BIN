﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography.X509Certificates;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using WcfService1.model;

namespace WcfService1
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom de classe "Service1" dans le code, le fichier svc et le fichier de configuration.
    // REMARQUE : pour lancer le client test WCF afin de tester ce service, sélectionnez Service1.svc ou Service1.svc.cs dans l'Explorateur de solutions et démarrez le débogage.
    public class Service1 : IService1
    {
        private readonly NorthwindEntities nwEntities = new NorthwindEntities();

        public void addCategory(string cat, string description)
        {
            nwEntities.Categories.Add(new Category() {CategoryName = cat, Description = description});
            nwEntities.SaveChanges();
        }

        public List<string> listCat()
        {
            List<string> catNames = new List<string>();
            foreach (var cat in nwEntities.Categories)
            {
                catNames.Add(cat.CategoryName);
            }
            return catNames;
        }

        public List<OrderDTO> listOrders()
        {
            List<OrderDTO> listOrders = new List<OrderDTO>();
            var query = from Order o in nwEntities.Orders
                where o.ShippedDate != null
                orderby o.OrderDate descending
                select o;
            int i = 0;
            foreach (var o in query)
            {
                OrderDTO om = new OrderDTO();
                om.ContactName = o.Customer.ContactName;
                om.OrderDate = o.OrderDate;
                om.ShippedDate = o.ShippedDate;
                listOrders.Add(om);
                if (i == 2)
                {
                    break;
                }
                i++;
            }
            return listOrders;
        }
    }
}