﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{
    // REMARQUE : vous pouvez utiliser la commande Renommer du menu Refactoriser pour changer le nom d'interface "IService1" à la fois dans le code et le fichier de configuration.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        void addCategory(string cat, string description);
        [OperationContract]
        List<string> listCat();
        [OperationContract]
        List<OrderDTO> listOrders();
    }
    [DataContract]
    public class OrderDTO
    {
        [DataMember]
        public string ContactName { get; set; }
        [DataMember]
        public DateTime? OrderDate { get; set; }
        [DataMember]
        public DateTime? ShippedDate { get; set; }

    }
}
