﻿using ExamJanvier.model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExamJanvier.ServiceReference1;
using WpfApplication1.viewmodel;

namespace ExamJanvier.viewmodel
{
    class VM : INotifyPropertyChanged
    {

        private string _catname;

        private string _descat;


        // Property changed standard handling
        public event PropertyChangedEventHandler PropertyChanged; // La view s'enregistera automatiquement sur cet event
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); // On notifie que la propriété a changé
            }
        }


        public string CatName
        {
            set { _catname = value;  }
        }

        public string DesCat
        {
            set { _descat = value; }
        }

        public List<String> ListCat
        {
            get
            {
               
                
                ServiceReference1.Service1Client svClient = new Service1Client();
                return svClient.listCat();

            }
        }


        public List<OrderDTO> ListOrders
        {
            get
            {

                ServiceReference1.Service1Client svClient = new Service1Client();
                return svClient.listOrders();
                
            }
        }


        private DelegateCommand _addCommand;

        public DelegateCommand AddCommand
        {
            get { return _addCommand = _addCommand ?? new DelegateCommand(AddCategorie); }

        }


        private void AddCategorie()
        {

            ServiceReference1.Service1Client svClient = new Service1Client();
            svClient.addCategory(_catname,_descat);
            OnPropertyChanged("ListCat");
        }
    }
}
