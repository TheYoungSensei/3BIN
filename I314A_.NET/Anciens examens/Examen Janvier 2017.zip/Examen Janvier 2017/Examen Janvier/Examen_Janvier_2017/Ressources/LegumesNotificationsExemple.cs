class LegumeModel : INotifyPropertyChanged {
   // Property changed standard handling
        public event PropertyChangedEventHandler PropertyChanged; 
        // La view s'enregistera automatiquement sur cet event
        protected virtual void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName)); 
            }
        }
�
set { _legume.name = value; OnPropertyChanged("Name"); }