﻿namespace Simon
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.rougeButton = new System.Windows.Forms.Button();
            this.BleuButton = new System.Windows.Forms.Button();
            this.jauneButton = new System.Windows.Forms.Button();
            this.vertButton = new System.Windows.Forms.Button();
            this.timerTrackBar = new System.Windows.Forms.TrackBar();
            this.startButton = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nbrCoupsLabel = new System.Windows.Forms.Label();
            this.highScoreLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.timerTrackBar)).BeginInit();
            this.SuspendLayout();
            // 
            // rougeButton
            // 
            this.rougeButton.BackColor = System.Drawing.Color.Red;
            this.rougeButton.Location = new System.Drawing.Point(399, 117);
            this.rougeButton.Margin = new System.Windows.Forms.Padding(4);
            this.rougeButton.Name = "rougeButton";
            this.rougeButton.Size = new System.Drawing.Size(100, 28);
            this.rougeButton.TabIndex = 0;
            this.rougeButton.Text = "button1";
            this.rougeButton.UseVisualStyleBackColor = false;
            this.rougeButton.Click += new System.EventHandler(this.rougeButton_Click);
            // 
            // BleuButton
            // 
            this.BleuButton.BackColor = System.Drawing.Color.Blue;
            this.BleuButton.Location = new System.Drawing.Point(299, 198);
            this.BleuButton.Margin = new System.Windows.Forms.Padding(4);
            this.BleuButton.Name = "BleuButton";
            this.BleuButton.Size = new System.Drawing.Size(100, 28);
            this.BleuButton.TabIndex = 2;
            this.BleuButton.Text = "button3";
            this.BleuButton.UseVisualStyleBackColor = false;
            this.BleuButton.Click += new System.EventHandler(this.BleuButton_Click);
            // 
            // jauneButton
            // 
            this.jauneButton.BackColor = System.Drawing.Color.Yellow;
            this.jauneButton.Location = new System.Drawing.Point(399, 257);
            this.jauneButton.Margin = new System.Windows.Forms.Padding(4);
            this.jauneButton.Name = "jauneButton";
            this.jauneButton.Size = new System.Drawing.Size(100, 28);
            this.jauneButton.TabIndex = 3;
            this.jauneButton.Text = "button4";
            this.jauneButton.UseVisualStyleBackColor = false;
            this.jauneButton.Click += new System.EventHandler(this.jauneButton_Click);
            // 
            // vertButton
            // 
            this.vertButton.BackColor = System.Drawing.Color.Lime;
            this.vertButton.Location = new System.Drawing.Point(521, 185);
            this.vertButton.Margin = new System.Windows.Forms.Padding(4);
            this.vertButton.Name = "vertButton";
            this.vertButton.Size = new System.Drawing.Size(100, 28);
            this.vertButton.TabIndex = 4;
            this.vertButton.Text = "button5";
            this.vertButton.UseVisualStyleBackColor = false;
            this.vertButton.Click += new System.EventHandler(this.vertButton_Click);
            // 
            // timerTrackBar
            // 
            this.timerTrackBar.Location = new System.Drawing.Point(320, 378);
            this.timerTrackBar.Margin = new System.Windows.Forms.Padding(4);
            this.timerTrackBar.Name = "timerTrackBar";
            this.timerTrackBar.Size = new System.Drawing.Size(267, 56);
            this.timerTrackBar.TabIndex = 5;
            // 
            // startButton
            // 
            this.startButton.Location = new System.Drawing.Point(131, 378);
            this.startButton.Margin = new System.Windows.Forms.Padding(4);
            this.startButton.Name = "startButton";
            this.startButton.Size = new System.Drawing.Size(100, 28);
            this.startButton.TabIndex = 6;
            this.startButton.Text = "Start";
            this.startButton.UseVisualStyleBackColor = true;
            this.startButton.Click += new System.EventHandler(this.startButton_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(325, 442);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(16, 17);
            this.label1.TabIndex = 7;
            this.label1.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(561, 442);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(24, 17);
            this.label2.TabIndex = 8;
            this.label2.Text = "10";
            // 
            // nbrCoupsLabel
            // 
            this.nbrCoupsLabel.AutoSize = true;
            this.nbrCoupsLabel.Location = new System.Drawing.Point(177, 71);
            this.nbrCoupsLabel.Name = "nbrCoupsLabel";
            this.nbrCoupsLabel.Size = new System.Drawing.Size(16, 17);
            this.nbrCoupsLabel.TabIndex = 9;
            this.nbrCoupsLabel.Text = "0";
            // 
            // highScoreLabel
            // 
            this.highScoreLabel.AutoSize = true;
            this.highScoreLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.highScoreLabel.Location = new System.Drawing.Point(128, 24);
            this.highScoreLabel.Name = "highScoreLabel";
            this.highScoreLabel.Size = new System.Drawing.Size(143, 29);
            this.highScoreLabel.TabIndex = 10;
            this.highScoreLabel.Text = "High Score";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(751, 501);
            this.Controls.Add(this.highScoreLabel);
            this.Controls.Add(this.nbrCoupsLabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.startButton);
            this.Controls.Add(this.timerTrackBar);
            this.Controls.Add(this.vertButton);
            this.Controls.Add(this.jauneButton);
            this.Controls.Add(this.BleuButton);
            this.Controls.Add(this.rougeButton);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Simon";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.timerTrackBar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rougeButton;
        private System.Windows.Forms.Button BleuButton;
        private System.Windows.Forms.Button jauneButton;
        private System.Windows.Forms.Button vertButton;
        private System.Windows.Forms.TrackBar timerTrackBar;
        private System.Windows.Forms.Button startButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label nbrCoupsLabel;
        private System.Windows.Forms.Label highScoreLabel;
    }
}

