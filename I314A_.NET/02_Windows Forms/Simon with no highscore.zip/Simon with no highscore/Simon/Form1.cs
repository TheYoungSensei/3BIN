﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Simon.Domaine;
using System.Threading;

namespace Simon
{
    public partial class Form1 : Form
    {
        SimonTheGame gameController;

        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            rougeButton.Enabled = false;
            vertButton.Enabled = false;
            jauneButton.Enabled = false;
            BleuButton.Enabled = false;
            startButton.Enabled = true;
            gameController = new SimonTheGame();
            gameController.AllumerButtonCallBack = OnAllumerBouton;
            gameController.TimeOutCallBack = OnTimeOut;

        }

        void threadSafeOnTimeOut()
        {

            rougeButton.Enabled = false;
            vertButton.Enabled = false;
            jauneButton.Enabled = false;
            BleuButton.Enabled = false;
            startButton.Enabled = true;



            Refresh();


            MessageBox.Show("Trop tard!!!");

        }


        void OnTimeOut()
        {
            // Thread safe invocation of the delegate
            this.Invoke(new Domaine.SimonTheGame.TimeOutDelegate(  threadSafeOnTimeOut));
            //threadSafeOnTimeOut(nbrCoup);
        }

        private void startButton_Click(object sender, EventArgs e)
        {
            rougeButton.Enabled = true;
            vertButton.Enabled = true;
            jauneButton.Enabled = true;
            BleuButton.Enabled = true;
            startButton.Enabled = false;

            gameController.nouvellePartie(timerTrackBar.Value);
        }

        private void OnAllumerBouton(IEnumerator<SimonTheGame.Couleur> suiteAAllumer)
        {
            Color initialColor;

            
            while (suiteAAllumer.MoveNext())
            {
                SimonTheGame.Couleur boutonAAllumer = suiteAAllumer.Current;
                switch (boutonAAllumer)
                {
                    case SimonTheGame.Couleur.Bleu:
                        initialColor = BleuButton.BackColor;
                        BleuButton.BackColor = Color.Beige;
                        this.Refresh();
                        Thread.Sleep(500);
                        BleuButton.BackColor = initialColor;
                        break;
                    case SimonTheGame.Couleur.Jaune:
                        initialColor = jauneButton.BackColor;
                        jauneButton.BackColor = Color.Beige;
                        this.Refresh();
                        Thread.Sleep(500);
                        jauneButton.BackColor = initialColor;
                        break;
                    case SimonTheGame.Couleur.Rouge:
                        initialColor = rougeButton.BackColor;
                        rougeButton.BackColor = Color.Beige;
                        this.Refresh();
                        Thread.Sleep(500);
                        rougeButton.BackColor = initialColor;
                        break;
                    case SimonTheGame.Couleur.Vert:
                        initialColor = vertButton.BackColor;
                        vertButton.BackColor = Color.Beige;
                        this.Refresh();
                        Thread.Sleep(500);
                        vertButton.BackColor = initialColor;
                        break;
                }
                Refresh(); // Important pour voir les changements de couleur
                Thread.Sleep(200);

            }

        }

        private void rougeButton_Click(object sender, EventArgs e)
        {
            SimonTheGame.ResultatCoup res = gameController.coupJoueur(SimonTheGame.Couleur.Rouge);
            if (res == SimonTheGame.ResultatCoup.SuiteComplete)
                // On relance
                gameController.uneEtapeEnPlus();
            if (res == SimonTheGame.ResultatCoup.KO)
            {
                MessageBox.Show("Mauvais coup");
                startButton.Enabled = true;
            }
        }

        private void vertButton_Click(object sender, EventArgs e)
        {
            SimonTheGame.ResultatCoup res = gameController.coupJoueur(SimonTheGame.Couleur.Vert);
            if (res == SimonTheGame.ResultatCoup.SuiteComplete)
                // On relance
                gameController.uneEtapeEnPlus();
            if (res == SimonTheGame.ResultatCoup.KO)
            {
                MessageBox.Show("Mauvais coup");
                startButton.Enabled = true;
            }
        }

        private void jauneButton_Click(object sender, EventArgs e)
        {
            SimonTheGame.ResultatCoup res = gameController.coupJoueur(SimonTheGame.Couleur.Jaune);
            if (res == SimonTheGame.ResultatCoup.SuiteComplete)
                // On relance
                gameController.uneEtapeEnPlus();
            if (res == SimonTheGame.ResultatCoup.KO)
            {
                MessageBox.Show("Mauvais coup");
                startButton.Enabled = true;
            }
        }

        private void BleuButton_Click(object sender, EventArgs e)
        {
            SimonTheGame.ResultatCoup res = gameController.coupJoueur(SimonTheGame.Couleur.Bleu);
            if (res == SimonTheGame.ResultatCoup.SuiteComplete)
                // On relance
                gameController.uneEtapeEnPlus();
            if (res == SimonTheGame.ResultatCoup.KO)
            {
                MessageBox.Show("Mauvais coup");
                startButton.Enabled = true;
            }
        }
    }
}
