﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace Simon.Domaine
{
    public class SimonTheGame
    {
        public enum Couleur { Rouge, Vert, Jaune, Bleu };
        public enum ResultatCoup { KO, OK, SuiteComplete };

        /// <summary>
        /// Délégué qui indique au client que le temps de réponse est expiré
        /// </summary>
        public delegate void TimeOutDelegate();
        /// <summary>
        /// Délégué qui indique au client quels sont les boutons à allumer
        /// </summary>
        /// <param name="suiteAAllumer">Enumérateur de la suite des boutons à allumer</param>
        public delegate void AllumerBoutonsDelegate(IEnumerator<Couleur> suiteAAllumer);

        private bool partieValideEnCours = false;
        private List<Couleur> suiteAReproduire;
        private int coup = 0;
        private int timeOutTime;
        private TimeOutDelegate timeOutCallBack;

        public TimeOutDelegate TimeOutCallBack
        {
            get { return timeOutCallBack; }
            set { timeOutCallBack = value; }
        }

        private AllumerBoutonsDelegate allumerButtonCallBack;

        public AllumerBoutonsDelegate AllumerButtonCallBack
        {
            get { return allumerButtonCallBack; }
            set { allumerButtonCallBack = value; }
        }

        Thread timerThread;

  
        /// <summary>
        /// Nombre de coups joué pour l'instant
        /// </summary>
        public int Coup
        {
            get { return coup; }
        }


        private Random random;
        private IEnumerator<Couleur> suiteCouranteEnumerator;

        /// <summary>
        /// Lance une nouvelle partie
        /// </summary>
        /// <param name="timeOutTime">Temps maximum entre deux réponses du joueur</param>
        public void nouvellePartie(int timeOutTime)
        {
            partieValideEnCours = true;
            this.timeOutTime = timeOutTime;
            coup = 0;
            suiteAReproduire = new List<Couleur>();
            random = new Random();

            uneEtapeEnPlus();
        }

        /// <summary>
        /// Demande de rajouter une étape à la suite de couleur existante.
        /// Déclenchera l'appel du délégué AllumerBoutonsCallBack
        /// </summary>
        public void uneEtapeEnPlus()
        {
            if (!partieValideEnCours)
                return;
            Array values = Enum.GetValues(typeof(Couleur));
            
            Couleur randomCouleur = (Couleur)values.GetValue(random.Next(values.Length));
            suiteAReproduire.Add(randomCouleur);

            suiteCouranteEnumerator = suiteAReproduire.GetEnumerator();
            suiteCouranteEnumerator.MoveNext(); // Il y en a au moins 1
            // Allumer les boutons
            allumerButtonCallBack(suiteAReproduire.GetEnumerator());

            // Lancer un thread ici!
            timerThread = new Thread(timeOutTimer);
            timerThread.Start();            
        }

        /// <summary>
        /// Enregistre le coup suivant du joueur.
        /// </summary>
        /// <param name="proposition">La couleur proposée</param>
        /// <returns>OK ou KO si la couleur est bonne ou mauvaise ou SuiteComplete lorsque la suite est terminée</returns>
        public ResultatCoup coupJoueur(Couleur proposition)
        {
            if (!partieValideEnCours)
                return ResultatCoup.KO;

            // Arrêt du thread
            if (timerThread != null)
                timerThread.Abort();

            // Ici mettre le jeu en erreur!!!
            partieValideEnCours = suiteCouranteEnumerator.Current == proposition;

            if (!partieValideEnCours)
                return ResultatCoup.KO;

            if (!suiteCouranteEnumerator.MoveNext()) // c'était le dernier coup
            {
                return ResultatCoup.SuiteComplete;
            }

            // On relance le thread
            timerThread = new Thread(timeOutTimer);
            timerThread.Start();
            return ResultatCoup.OK;
        }

        private void timeOutTimer()
        {
            Thread.Sleep(timeOutTime*1000);
            Console.WriteLine("Time out!");

            timeOutCallBack();
        }

    }
}
