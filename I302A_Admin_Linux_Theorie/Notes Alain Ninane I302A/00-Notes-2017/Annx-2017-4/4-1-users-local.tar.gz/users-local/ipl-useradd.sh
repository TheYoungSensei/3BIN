#! /bin/bash

  set -x

  if [ ! -w / ]; then
	echo $0: You must be root to run this application
	exit 1
  fi

  if [ $# -ne 3 ]; then
	echo Usage: $0 user password realname
	exit 2
  fi

  user=$1
  pass=$2
  gecos=$3
  hdir=$(perl -e "print 'home/'.substr($user,0,1).'/$user'")

################################################################################
# Create user on the server
################################################################################
  groupadd $user
  mkdir -p /disks/$hdir
  ln -s /disks/$hdir /home/$user
  useradd -g $user -p INACTIVE -d /home/$user -c "$gecos" $user
  chown $user.$user /disks/$hdir
  su -c "cd /home/$user ; cp -rp /etc/skel/.??* . " $user
  echo $pass | passwd --stdin $user

exit 0
