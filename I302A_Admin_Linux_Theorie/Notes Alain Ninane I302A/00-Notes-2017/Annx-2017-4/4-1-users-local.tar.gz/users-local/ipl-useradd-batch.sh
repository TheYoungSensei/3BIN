#! /bin/bash

# awk -F: '{print $1, $2, "\""$3"\"";}' ipl-list-users | xargs -l1 echo
  awk -F: '{print $1, $2, "\""$3"\"";}' ipl-list-users | xargs -l1 ./ipl-useradd.sh

exit
